package org.apollorm.function;

public class File {
    public static String helloWorld() {
        return "Hello, world";
    }
}
